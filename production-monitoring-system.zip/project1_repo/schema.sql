-- Production Monitoring & Incident Analysis System
-- Database Schema

CREATE DATABASE IF NOT EXISTS monitoring_db;
USE monitoring_db;

-- System Logs Table
CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    log_level ENUM('INFO','WARNING','ERROR','CRITICAL') NOT NULL,
    message TEXT NOT NULL,
    source_ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service (service_name),
    INDEX idx_level (log_level),
    INDEX idx_created (created_at)
);

-- Incidents Table
CREATE TABLE IF NOT EXISTS incidents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    severity ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'LOW',
    status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') DEFAULT 'OPEN',
    service_name VARCHAR(100),
    assigned_to VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    INDEX idx_status (status),
    INDEX idx_severity (severity)
);

-- Health Checks Table
CREATE TABLE IF NOT EXISTS health_checks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    status ENUM('UP','DOWN','DEGRADED') NOT NULL,
    response_time_ms INT,
    error_message TEXT,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service (service_name),
    INDEX idx_checked (checked_at)
);

-- ─────────────────────────────────────────────
-- Sample Data
-- ─────────────────────────────────────────────
INSERT INTO system_logs (service_name, log_level, message, source_ip) VALUES
('auth-service', 'INFO', 'User login successful: user_id=1042', '192.168.1.10'),
('payment-service', 'ERROR', 'Payment gateway timeout after 30s', '192.168.1.22'),
('api-gateway', 'WARNING', 'Rate limit approaching: 90% of quota used', '10.0.0.5'),
('db-service', 'CRITICAL', 'Connection pool exhausted: 0 connections available', '10.0.0.1'),
('auth-service', 'INFO', 'Token refresh for user_id=2233', '192.168.1.10');

INSERT INTO incidents (title, description, severity, status, service_name, assigned_to) VALUES
('Payment Gateway Timeout', 'Payments failing due to gateway timeout', 'HIGH', 'OPEN', 'payment-service', 'ops-team'),
('DB Connection Pool Exhausted', 'No DB connections available causing 500 errors', 'CRITICAL', 'IN_PROGRESS', 'db-service', 'dba-team'),
('API Rate Limit Warning', 'Nearing rate limit on API gateway', 'MEDIUM', 'OPEN', 'api-gateway', 'dev-team');

INSERT INTO health_checks (service_name, status, response_time_ms, error_message) VALUES
('auth-service', 'UP', 45, NULL),
('payment-service', 'DOWN', NULL, 'Connection refused'),
('api-gateway', 'DEGRADED', 850, 'High latency detected'),
('db-service', 'UP', 12, NULL);
