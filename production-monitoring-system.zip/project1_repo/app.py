"""
Production Monitoring and Incident Analysis System
Flask + MySQL Application
"""

from flask import Flask, request, jsonify, render_template
from datetime import datetime
import mysql.connector
from mysql.connector import Error
import logging
import traceback

app = Flask(__name__)

# ─────────────────────────────────────────────
# Logging Setup
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# DB Config
# ─────────────────────────────────────────────
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "monitoring_db"
}

def get_db_connection():
    """Create and return a MySQL connection."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        logger.error(f"Database connection failed: {e}")
        raise


def init_db():
    """Initialize DB schema."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS system_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_name VARCHAR(100) NOT NULL,
            log_level ENUM('INFO','WARNING','ERROR','CRITICAL') NOT NULL,
            message TEXT NOT NULL,
            source_ip VARCHAR(45),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            severity ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'LOW',
            status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') DEFAULT 'OPEN',
            service_name VARCHAR(100),
            assigned_to VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resolved_at TIMESTAMP NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS health_checks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_name VARCHAR(100) NOT NULL,
            status ENUM('UP','DOWN','DEGRADED') NOT NULL,
            response_time_ms INT,
            error_message TEXT,
            checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    cursor.close()
    conn.close()
    logger.info("Database initialized successfully.")


# ─────────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────────
@app.route("/")
def dashboard():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT COUNT(*) AS total FROM system_logs")
        total_logs = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(*) AS total FROM incidents WHERE status='OPEN'")
        open_incidents = cursor.fetchone()["total"]

        cursor.execute("""
            SELECT service_name, status, checked_at
            FROM health_checks
            WHERE checked_at = (SELECT MAX(checked_at) FROM health_checks hc2 WHERE hc2.service_name = health_checks.service_name)
            ORDER BY service_name
        """)
        health_status = cursor.fetchall()

        cursor.execute("""
            SELECT log_level, COUNT(*) AS count
            FROM system_logs
            GROUP BY log_level
        """)
        log_summary = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template("dashboard.html",
                               total_logs=total_logs,
                               open_incidents=open_incidents,
                               health_status=health_status,
                               log_summary=log_summary)
    except Exception as e:
        logger.error(f"Dashboard error: {traceback.format_exc()}")
        return jsonify({"error": "Failed to load dashboard", "details": str(e)}), 500


# ─────────────────────────────────────────────
# Log Capture API
# ─────────────────────────────────────────────
@app.route("/api/logs", methods=["POST"])
def capture_log():
    """Capture a system log entry."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON payload provided"}), 400

        required = ["service_name", "log_level", "message"]
        for field in required:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        valid_levels = ["INFO", "WARNING", "ERROR", "CRITICAL"]
        if data["log_level"].upper() not in valid_levels:
            return jsonify({"error": f"Invalid log_level. Must be one of {valid_levels}"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO system_logs (service_name, log_level, message, source_ip)
            VALUES (%s, %s, %s, %s)
        """, (
            data["service_name"],
            data["log_level"].upper(),
            data["message"],
            request.remote_addr
        ))
        conn.commit()
        log_id = cursor.lastrowid
        cursor.close()
        conn.close()

        logger.info(f"Log captured: [{data['log_level']}] {data['service_name']} - {data['message']}")
        return jsonify({"message": "Log captured", "id": log_id}), 201

    except Error as e:
        logger.error(f"DB error capturing log: {e}")
        return jsonify({"error": "Database failure", "details": str(e)}), 500
    except Exception as e:
        logger.error(f"Unexpected error: {traceback.format_exc()}")
        return jsonify({"error": "Internal server error"}), 500


@app.route("/api/logs", methods=["GET"])
def get_logs():
    """Retrieve logs with optional filters."""
    try:
        service = request.args.get("service")
        level = request.args.get("level")
        limit = int(request.args.get("limit", 100))

        query = "SELECT * FROM system_logs WHERE 1=1"
        params = []

        if service:
            query += " AND service_name = %s"
            params.append(service)
        if level:
            query += " AND log_level = %s"
            params.append(level.upper())

        query += " ORDER BY created_at DESC LIMIT %s"
        params.append(limit)

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        logs = cursor.fetchall()
        cursor.close()
        conn.close()

        for log in logs:
            if log.get("created_at"):
                log["created_at"] = log["created_at"].isoformat()

        return jsonify({"logs": logs, "count": len(logs)}), 200

    except Exception as e:
        logger.error(f"Error fetching logs: {traceback.format_exc()}")
        return jsonify({"error": "Failed to retrieve logs", "details": str(e)}), 500


# ─────────────────────────────────────────────
# Incident Management
# ─────────────────────────────────────────────
@app.route("/api/incidents", methods=["POST"])
def create_incident():
    """Create a new incident."""
    try:
        data = request.get_json()
        if not data or "title" not in data:
            return jsonify({"error": "title is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO incidents (title, description, severity, service_name, assigned_to)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            data["title"],
            data.get("description", ""),
            data.get("severity", "LOW").upper(),
            data.get("service_name", ""),
            data.get("assigned_to", "")
        ))
        conn.commit()
        incident_id = cursor.lastrowid
        cursor.close()
        conn.close()

        logger.warning(f"Incident created: [{data.get('severity','LOW')}] {data['title']}")
        return jsonify({"message": "Incident created", "id": incident_id}), 201

    except Exception as e:
        logger.error(f"Error creating incident: {traceback.format_exc()}")
        return jsonify({"error": "Failed to create incident", "details": str(e)}), 500


@app.route("/api/incidents", methods=["GET"])
def get_incidents():
    """Get all incidents with optional status filter."""
    try:
        status = request.args.get("status")
        severity = request.args.get("severity")

        query = "SELECT * FROM incidents WHERE 1=1"
        params = []

        if status:
            query += " AND status = %s"
            params.append(status.upper())
        if severity:
            query += " AND severity = %s"
            params.append(severity.upper())

        query += " ORDER BY created_at DESC"

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        incidents = cursor.fetchall()
        cursor.close()
        conn.close()

        for inc in incidents:
            for field in ["created_at", "resolved_at"]:
                if inc.get(field):
                    inc[field] = inc[field].isoformat()

        return jsonify({"incidents": incidents, "count": len(incidents)}), 200

    except Exception as e:
        logger.error(f"Error fetching incidents: {traceback.format_exc()}")
        return jsonify({"error": "Failed to retrieve incidents", "details": str(e)}), 500


@app.route("/api/incidents/<int:incident_id>/resolve", methods=["PUT"])
def resolve_incident(incident_id):
    """Mark an incident as resolved."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE incidents
            SET status = 'RESOLVED', resolved_at = %s
            WHERE id = %s
        """, (datetime.utcnow(), incident_id))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Incident not found"}), 404

        cursor.close()
        conn.close()

        logger.info(f"Incident {incident_id} resolved.")
        return jsonify({"message": f"Incident {incident_id} resolved"}), 200

    except Exception as e:
        logger.error(f"Error resolving incident: {traceback.format_exc()}")
        return jsonify({"error": "Failed to resolve incident"}), 500


# ─────────────────────────────────────────────
# Health Check API
# ─────────────────────────────────────────────
@app.route("/api/health", methods=["POST"])
def record_health():
    """Record a health check result."""
    try:
        data = request.get_json()
        if not data or "service_name" not in data or "status" not in data:
            return jsonify({"error": "service_name and status are required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO health_checks (service_name, status, response_time_ms, error_message)
            VALUES (%s, %s, %s, %s)
        """, (
            data["service_name"],
            data["status"].upper(),
            data.get("response_time_ms"),
            data.get("error_message")
        ))
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"message": "Health check recorded"}), 201

    except Exception as e:
        logger.error(f"Error recording health check: {traceback.format_exc()}")
        return jsonify({"error": "Failed to record health check"}), 500


@app.route("/api/health", methods=["GET"])
def get_health():
    """Get latest health status for all services."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT h1.*
            FROM health_checks h1
            INNER JOIN (
                SELECT service_name, MAX(checked_at) AS latest
                FROM health_checks
                GROUP BY service_name
            ) h2 ON h1.service_name = h2.service_name AND h1.checked_at = h2.latest
            ORDER BY h1.service_name
        """)
        results = cursor.fetchall()
        cursor.close()
        conn.close()

        for r in results:
            if r.get("checked_at"):
                r["checked_at"] = r["checked_at"].isoformat()

        return jsonify({"services": results}), 200

    except Exception as e:
        logger.error(f"Error fetching health: {traceback.format_exc()}")
        return jsonify({"error": "Failed to retrieve health data"}), 500


# ─────────────────────────────────────────────
# Operational Reports
# ─────────────────────────────────────────────
@app.route("/api/reports/summary", methods=["GET"])
def report_summary():
    """Generate an operational summary report."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT log_level, COUNT(*) AS count
            FROM system_logs
            WHERE created_at >= NOW() - INTERVAL 24 HOUR
            GROUP BY log_level
        """)
        log_counts = cursor.fetchall()

        cursor.execute("""
            SELECT severity, status, COUNT(*) AS count
            FROM incidents
            GROUP BY severity, status
            ORDER BY severity, status
        """)
        incident_summary = cursor.fetchall()

        cursor.execute("""
            SELECT service_name, AVG(response_time_ms) AS avg_response_ms,
                   SUM(CASE WHEN status='DOWN' THEN 1 ELSE 0 END) AS down_count
            FROM health_checks
            WHERE checked_at >= NOW() - INTERVAL 24 HOUR
            GROUP BY service_name
        """)
        service_perf = cursor.fetchall()

        cursor.close()
        conn.close()

        return jsonify({
            "report_generated_at": datetime.utcnow().isoformat(),
            "last_24h_logs": log_counts,
            "incident_summary": incident_summary,
            "service_performance": service_perf
        }), 200

    except Exception as e:
        logger.error(f"Error generating report: {traceback.format_exc()}")
        return jsonify({"error": "Failed to generate report"}), 500


# ─────────────────────────────────────────────
# Error Handlers
# ─────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed"}), 405

@app.errorhandler(500)
def internal_error(e):
    logger.critical(f"Unhandled exception: {e}")
    return jsonify({"error": "Internal server error"}), 500


# ─────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
